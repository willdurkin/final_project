$(document).ready(function(){
	$('#submit').click(function(){
		$('#submit_body').css('visibility', 'visible')
	})
})